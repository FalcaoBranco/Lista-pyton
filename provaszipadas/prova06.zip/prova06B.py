import random

def inteiro_aleatoria_10_20():
    numero_aleatorio = random.randint(10,20)
    print(numero_aleatorio)

inteiro_aleatoria_10_20()