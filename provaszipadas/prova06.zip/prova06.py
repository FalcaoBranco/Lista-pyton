import random



lista = [1, 2, 3, 4, 5]

x = random.choice(lista)
# Você esta importando uma biblioteca para fazer escolhas aleatorias 
