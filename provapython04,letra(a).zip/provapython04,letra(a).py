def maior_numero():
    n1 = float(input('Digite um numero: '))
    n2 = float(input('Digite outro numero: '))
    if n1 > n2:
        maior = n1
    elif n2 > n1:
        maior = n2
    print(maior)
        
maior_numero()


