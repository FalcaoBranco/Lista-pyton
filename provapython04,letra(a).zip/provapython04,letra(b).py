def maior_numero():
    n1 = float(input('Digite um numero: '))
    n2 = float(input('Digite outro numero: '))
    maior = max(n1, n2)
    print(maior)
        
maior_numero()


