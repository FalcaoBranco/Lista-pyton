SELECT AVG(nota) AS media_notas
FROM Matricula
WHERE id_disciplina = {id_da_disciplina};
